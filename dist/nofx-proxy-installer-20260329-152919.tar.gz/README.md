# Proxy Installer

这个目录用于生成一个可上传到新云主机执行的 SOCKS5 代理安装包。

## 包含内容

- `install_socks5_proxy.sh`
  自动化安装脚本。默认用户名 `afx`、端口 `1080`、监听地址 `0.0.0.0`，并自动生成 8 位 SOCKS5 代理认证密码。执行后会自动完成：
  - 安装依赖
  - 下载并编译 `microsocks`
  - 写入 systemd 服务
  - 开机自启
  - 尝试放行防火墙端口
  - 本地自检代理出口

## 目标机器使用方式

上传并解压安装包后执行：

```bash
sudo bash install_socks5_proxy.sh
```

也可以覆盖默认用户名、端口或密码：

```bash
sudo bash install_socks5_proxy.sh \
  --username afx \
  --port 1080
```

安装完成后，脚本会直接输出可填到 NOFX 的 `proxy_url`，格式类似：

```text
socks5://afx:8位自动密码@47.91.11.229:1080
```

## 要求

- Linux 云主机
- root 权限
- 主机能访问公网下载依赖和 `microsocks` 源码
- 云厂商安全组已放行对应端口

## 已测试适配逻辑

脚本内置了以下包管理器检测：

- `apt`
- `dnf`
- `yum`
- `apk`

## 常用排查

查看服务状态：

```bash
systemctl status microsocks
```

查看日志：

```bash
journalctl -u microsocks -n 100 --no-pager
```

重启服务：

```bash
systemctl restart microsocks
```
